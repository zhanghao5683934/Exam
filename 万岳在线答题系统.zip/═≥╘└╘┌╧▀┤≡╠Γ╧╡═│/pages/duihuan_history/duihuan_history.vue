<template>
	<view>
		<!-- 订单兑换记录 -->
		
		<view class="" v-if="JSON.stringify(history) != '{}'">
			<view class="his-item" v-for="(item, index) in history" :key="index">
				<view class="trade-no font_24 color_32">订单编号: {{item.out_trade_no}}</view>
				<view class="goods-info"> 
					<text class="goods-type color_32">{{item.goods_name}}</text>
					<text class="shouli font_24 color_red" style="border: 2rpx solid #FE5A13;" v-if="item.is_send == 0">待受理</text>
					<text class="shouli font_24 color_96" v-if="item.is_send == 1">已受理</text>
					<text class="reduce-price color_96">-{{item.score_price}}</text>
					<image class="trade-money-icon money-icon" src="../../static/images/shop-score.png" mode="aspectFit"></image>
				</view>
				<view class="font_24 color_96">
					兑换时间:<text class="dh-time">{{item.addtime}}</text>
				</view>	
			</view>
		</view>
		
		<view class="index-tips" v-if="is_kongkong == true">
			暂无任何兑换记录！
		</view>
		
	</view>
</template>

<script>
	const app = getApp();
	
	export default {
		data() {
			return {
				course_info: {},
				history: {},
				is_kongkong: false
			}
		},
		onLoad() {
			this.getDuihuanHistory();
		},
		methods: {
			getDuihuanHistory(){
				let that = this;
				uni.request({
					url: app.globalData.site_url+'/appapi/?s=User.GetDuihuanHistory',
					method: 'GET',
					data: {
						'uid': app.globalData.userInfo.id,
						'token': app.globalData.userInfo.token
					},
					success: res => {
						
						if(res.data.data.code == 0) {
							that.history = res.data.data.info[0];
							if(that.history.length < 1) {
								that.is_kongkong = true;
							}
						}
					},
					fail: () => {},
					complete: () => {}
				});
			}
			
		}
	}
</script>

<style>
	
	page {
		background-color: #FAFAFA;
	}
	
	.his-item {
		width: 96%;
		height: 180rpx;
		margin: 0 auto 20rpx;
		padding-top: 10rpx;
		padding-left: 15rpx;
		background-color: #FFFFFF;	
		border-radius: 15rpx;
	}
	
	.trade-no {
		
	}
	
	.goods-info {
		height: 60rpx;
		margin-bottom: 40rpx;
		display: flex;
		align-items: center;
		position: relative;
	}
	
	.goods-type {
		max-width: 62%;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
	}
	
	.shouli {
		margin-left: 10rpx;
		display: inline-block;
		padding: 4rpx;
		border: 2rpx solid #969696;
		border-radius: 5rpx;
	}
	
	.trade-money-icon {
		position: absolute;
		right: 40rpx;
	}
	.reduce-price {
		width: 150rpx;
		text-align: right;
		position: absolute;
		right: 90rpx;
	}
	
	.dh-time {
		display: inline-block;
		padding-left: 10rpx;
	}
	
	.index-tips{
		margin-top: 300rpx;
		color: #969696;
		text-align: center;
	}
	
</style>

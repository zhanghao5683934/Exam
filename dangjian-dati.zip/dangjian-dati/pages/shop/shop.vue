<template>
	<view @click="showPointMsg(2)">
		
		<!-- #ifndef H5 -->
		<!-- <nav-title title="积分商城" ></nav-title>	
		<text @click="fanhui" class="iconfont icon-fanhui1 fanhui-icon" ></text> -->
		<!-- #endif -->

		<!-- 积分区 -->
		<view class="score-wrap">
			<view class="score-title">
				<text>当前可用积分</text>
				<image @click.stop="showPointMsg(1)" class="wenhao_icon" src="../../static/images/wenhao_icon.png" mode="aspectFit"></image>
				<view v-if="showPoint" class="point-wrap">
					<view class="arow"></view>
					<view class="point-title">如何获取积分?</view>
					<view class="point-article">
						1.每天第一次登录;<br>
						2.每阅读一篇文章,包括:<br>要闻速览、基层动态、产品介绍;<br>
						3.有声读物听完并答题完毕后。
					</view>
				</view>	
			</view>
			<view class="score-value color_ff">{{parseInt(userScore) > 0 ? parseInt(userScore) : 0}}</view>
					
			<view class="score-his">
				<view class="score-item font_24 color_ff">
					<image class="duihuan-icon his-icon" src="../../static/images/duihuan_icon.png" mode="aspectFit"></image>
					<text @click="openDuiHistory">兑换记录</text>
				</view>
				<text class="shu"></text>
				<view class="score-item font_24 color_ff">
					<image class="his-icon" src="../../static/images/shop_score_icon.png" mode="aspectFit"></image>
					<text @click="openScoreHistory">积分记录</text>
				</view>
			</view>
		</view>
		
		
		<!-- 商品列表区 -->
		<view class="goods-list">
			<view @click="viewGoodsInfo(item.id)" v-for="(item, index) in list" :key="index" class="goods-item">
				<image class="goods-img" :src="item.thumb" mode="aspectFit"></image>
				<text class="goods-title">{{item.title}}</text>
				<view class="goods-bottom">
					<image class="money-img" src="../../static/images/shop-score.png" mode="aspectFill"></image>
					<text class="price">{{item.score}}</text>
					<text class="duihuan-txt color_ff">兑换</text>
				</view>
			</view>
		</view>
		
		
	</view>
</template>

<script>
	import navTitle from '@/components/nav-title/nav-title.vue';
	import request from '@/util/request.js';
	const app = getApp();
	export default {
		components:{
			navTitle,
		},
		onShow(){
			
			this.getUserInfo();
			this.getGoodsList();
			var url = app.globalData.site_url+'/appapi/?s=Home.GetConfig';
			request.requestApi(url,{}).then(res=>{
				this.configInfo = res.data.info[0];
				
			})
		},
		onReachBottom(){
			
		},
		data() {
			return {
				list:[],
				page:1,
				configInfo:[],
				isBottom:false,//有没有到底部
				userScore: '',
				showPoint: false, // 是否展示提示信息
			}
		},
		methods: {
			
			// 显示提示信息 
			showPointMsg(type){
				if(type == 1) {
					this.showPoint = true;
				} else {
					this.showPoint = false;
				}
				
			},
			//跳转到首页
			fanhui(){
				uni.reLaunch({
					url: '../index/index',
				})
			},
			//重新获取用户信息 积分实时更新
			getUserInfo() {
				uni.request({
					url: app.globalData.site_url+'/appapi/?s=Shop.getUserScore',
					method: 'GET',
					data: {
						'uid' : app.globalData.userInfo.id,
						'token': app.globalData.userInfo.token,
					},
					success: res => {
						if(res.data.data.code == 0) {
							this.userScore = res.data.data.info[0].score;
						}
					},
				});
			},
			getGoodsList() {
				uni.request({
					url: app.globalData.site_url+'/appapi/?s=Shop.GetGoodsList',
					method: 'GET',
					data: {},
					success: res => {
						console.log(res);
						if(res.data.data.code != 0) {
							return;
						}
						this.list = res.data.data.info[0];
					},
					fail: () => {
						uni.showToast({
							icon: 'none',
							title: '网络错误'
						});
					},
				
				});
				
			},
			// 查看商品详情
			viewGoodsInfo(good_id) {
				if(app.globalData.userInfo.is_admin_import == 0) {
					let authData = app.globalData.front_auth;
					console.log(authData);
					if(authData.indexOf('goods_info/goods_info') != '-1') {
						uni.showToast({
							icon:'none',
							title: '您没有此页面访问权限',
						});
						return;
					}
				}
				
				let good_data = [];
				for (let idx in this.list) {
					if(this.list[idx].id == good_id) {
						good_data = this.list[idx];
					}
				}
				console.log(good_data);
				uni.navigateTo({
					url: '../goods_info/goods_info?info=' + JSON.stringify(good_data),
				});
			},
			// 积分记录
			openScoreHistory(){
				if(app.globalData.userInfo.is_admin_import == 0) {
					let authData = app.globalData.front_auth;
					if(authData.indexOf('score_history/score_history') != '-1') {
						uni.showToast({
							icon:'none',
							title: '您没有此页面访问权限',
						});
						return;
					}
				}
				uni.navigateTo({
					url: '../score_history/score_history'
				});
			},
			// 兑换记录
			openDuiHistory() {
				if(app.globalData.userInfo.is_admin_import == 0) {
					let authData = app.globalData.front_auth;
					if(authData.indexOf('duihuan_history/duihuan_history') != '-1') {
						uni.showToast({
							icon:'none',
							title: '您没有此页面访问权限',
						});
						return;
					}
				}
				uni.navigateTo({
					url: '../duihuan_history/duihuan_history',
				});
			},
			writeThink(){ //编写思想交流
				var userInfo = app.globalData.userInfo;
				if(userInfo.id){
					uni.navigateTo({
						url:'/pages/publish/index'
					})
				}else{
					uni.redirectTo({
						url:'/pages/login/index'
					})
				}

			}
		}
	}
</script>

<style>
	
	.think-write{
	    position: fixed;
	    width: 80rpx;
	    height: 80rpx;
	    right: 30rpx;
	    bottom: 40rpx;
	}
	
	.score-wrap {
		background-color: #4CD964;
		background: linear-gradient(to right, #EE5D2A, #FFA349);
		height: 250rpx;
		/* #ifdef MP-WEIXIN */
		margin-top: 10rpx;
		/* #endif */
	}
	.score-jifen{
		position: relative;
		top: 59%;
		transform: translateY(-50%);
		font-weight: 700;
		font-size: 17px !important;
		color: #000000;
	}
	.score-title {
		height: 70rpx;
		width: 100%;
		line-height: 70rpx;
		text-align: center;
		padding-top: 10rpx;
		color: #FFFFFF;
		text-align: center;
		font-size: 28rpx;
		position: relative;
	}
	
	.wenhao_icon {
		display: inline-block;
		width: 25rpx;
		height: 25rpx;
		margin-left: 10rpx;
	}
	
	.score-value {
		font-size: 60rpx;
		text-align: center;
		margin-bottom: 10rpx;
	}
	
	.score-his {
		position: relative;
		border-top: 2rpx solid #FFFFFF;
	}
	
	.his-icon {
		display: inline-block;
		width: 45rpx;
		height: 35rpx;
	}
	
	.score-item {
		float: left;
		width: 49%;
		height: 80rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}	
	
	.shu {
		position: absolute;
		left: 49%;
		top: 12rpx;
		width: 2rpx;
		height: 50rpx;
		background-color: #FFFFFF;
	}
	
	.goods-list {
		width: 92%;
		margin: 0 auto;
		padding-top: 18rpx;
	}
	
	.goods-list::after{
		 content:"";
		  height: 0;
		  line-height: 0;
		  display: block;
		  clear: both;
		  visibility: hidden;/*将元素隐藏起来*/
	}
	
	.goods-item {
		width: 48%;
		height: 380rpx;
		float: left;
		margin-right: 24rpx;
		margin-bottom: 26rpx;
		box-shadow:rgba(0,0,0,.3) 0px 0px 15rpx;
		border-radius: 10rpx;
	}
	
	.goods-img {
		width: 100%;
		height: 260rpx;
	}
	
	.goods-item:nth-child(2n){
		margin-right: 0;
	}
	
	.goods-title {
		display: block;
		width: 95%;
		margin: 0 auto;
		text-align: center;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}
	
	.goods-bottom {
		padding: 0 10rpx;
		display: flex;
		align-items: center;
		width: 95%;
		margin: 10rpx auto 0;
	}
	
	.money-img {
		display: inline-block;
		width: 40rpx;
		height: 40rpx;
		margin-right: 10rpx;
	}
	
	.price {
		display: inline-block;
		width: 160rpx;
	}
	
	.duihuan-txt {
		width: 110rpx;
		text-align: center;
		border-radius: 10rpx;
		font-size: 30rpx;
		background-color: #FE5A13;
	}
	
	
	/* 提示框 */
	.point-wrap {
		width: 230rpx;
		height: 220rpx;
		position: absolute;
		top: 10rpx;
		right: 14rpx;
		background-color: #2B2B2B;
		z-index: 999;
		border-radius: 10rpx;
		padding: 7rpx;
	}
		
	.arow{
		position: absolute;
		left: -24rpx;
		top: 10%;
		width:0rpx;
		height:0rpx;
		border-top: 14rpx solid transparent;
		border-left: 14rpx solid transparent;
		border-right: 14rpx solid #2B2B2B;
		border-bottom: 14rpx solid transparent;
	}
		
	.point-title {
		font-size: 24rpx;
		height: 40rpx;
		line-height: 40rpx;
	}
	
	.point-article {
		border-top: 2rpx solid #969696;
		line-height: 25rpx;
		font-size: 22rpx;
		text-align: left;
		padding: 10rpx;
	}
	
	
	
</style>

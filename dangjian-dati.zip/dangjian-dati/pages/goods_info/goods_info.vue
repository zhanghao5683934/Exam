]<template>
	<view>
		<!--商品详情 -->
		
		<!-- banner -->
		<view class="goods-banner-wrap">
			<swiper class="swiper" indicator-active-color="#FF311C" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000">
				<swiper-item v-for="(item, index) in goodInfo.multi_thumb" :key="index">
					<image class="swiper-item" :src="item" mode="aspectFit"></image>
				</swiper-item>
			</swiper>
		</view>
		
		<!-- 下半部分 -->
		<view class="goods-bottom">
			<!-- 标题 -->
			<view class="goods-title-wrap">
				<view class="goods-title-top">
					<text class="goods-title">{{goodInfo.title}}</text>
					<view class="goods-info-price font_26 color_red">
						<image class="money-icon" src="../../static/images/shop-score.png" mode="aspectFit"></image>
						{{goodInfo.score}}
					</view>
				</view>
				
				<view class="goods-base font_26 color_96">
					{{goodInfo.content}}
				</view>
			</view>
			
			<!-- 注意事项 -->
			<view class="notice-wrap">
				<view class="notice-title color_32 font_32">注意事项</view>
				<view class="notice-info color_33 font_26">1.点击立即兑换, 兑换成功后, 1~7个工作日受理。</view>
				<view class="notice-info color_33 font_26">2.商品兑换请仔细阅读并参照商品详情, 除商品本身不能正常兑换外, 商品一经兑换, 一律不退还积分。</view>
				
			</view>
			
			<!-- 兑换按钮 -->
			<text @click="confirmDuihuan" class="duihuan-btn">立即兑换</text>
			
			
		</view>
		
		
		
		
		
		
	</view>
</template>

<script>
	const app = getApp();
	export default {
		data() {
			return {
				goodInfo: {}, //商品详情
			}
		},
		onLoad(option) {
			if(option.info != undefined) {
				this.goodInfo = JSON.parse(option.info);
			}
		},
		methods: {
			// 兑换
			confirmDuihuan() {
				let that = this;
				
				uni.showModal({
					title: '确认兑换',
					content: this.goodInfo.title,
					showCancel: true,
					cancelText: '取消',
					cancelColor: '#969696',
					confirmText: '确认',
					confirmColor: '#FE5A13',
					success: res => {
						if (res.confirm) {
							that.duihuan();
						}
					},
					fail: () => {},
					complete: () => {}
				});
			},
			duihuan() {
				
				let that = this;
				uni.request({
					url:  app.globalData.site_url+'/appapi/?s=Shop.Exchange',
					method: 'GET',
					data: {
						'uid': app.globalData.userInfo.id,
						'token': app.globalData.userInfo.token,
						'good_id': that.goodInfo.id
					},
					success: res => {	
						console.log(res);
						if(res.data.data.code != 0) {
							uni.showToast({
								icon: 'none',
								title: res.data.data.msg
							});
							return;
						}
						// 返回订单号
						let trade_no = res.data.data.info[0].trade_no;
						uni.navigateTo({
							url: '../duihuan_success/duihuan_success?trade_no=' + trade_no,
						});
						
					},
					fail: () => {},
				});
			}
			
		}
	}
</script>

<style>
	
	page {
		background-color: #FFFFFF;
		min-height: 1400rpx;
	}
	
	.goods-banner-wrap {
		height: calc(60vh);
		border-bottom: 10rpx solid #FAFAFA;
		padding: 0 20rpx;
	}
	
	.swiper {
		height: 100%;
	}
	
	.swiper-item {
		display: inline-block;
		width: 100%;
		height: 100%;
		margin: 0 auto;
	}
	
	
	/* 下半部分 */
	.goods-bottom {
		width: 94%;
		margin: 0 auto;
	}
	
	.goods-title-wrap {
		border-bottom: 2rpx solid #EAEAEA;
	}
	
	.goods-title-top {
		position: relative;
		display: flex;
		align-items: center;
	}
	
	.goods-title {
		width: 70%;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
	}
	
	.goods-info-price {
		position: absolute;
		min-width: 100rpx;
		right: 0rpx;
		text-align: right;
		display: flex;
		align-items: center;
	}
	
	.goods-base {
		margin-top: 10rpx;
	}
	
	
	/* 注意事项 */
	.notice-wrap {
		padding-top: 40rpx;
	}
	
	.notice-title {
		margin-bottom: 10rpx;
	}
	
	.notice-info {
		margin-bottom: 20rpx;
	}
	
	.duihuan-btn {
		display: inline-block;
		width: 82%;
		height: 80rpx;
		line-height: 80rpx;
		color: #FEFEFE;
		text-align: center;
		border-radius: 40rpx;
		position: fixed; 
		left: 50%; 
		bottom: 2rpx;
		transform: translate(-50%, -50%);
		background: linear-gradient(to left, #FF9000, #F64330);
		
	}	
	
	

</style>

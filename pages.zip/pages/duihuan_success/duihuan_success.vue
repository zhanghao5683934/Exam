<template>
	<view>
		<view class="success-wrap">
			<image class="success-icon" src="../../static/images/dh-success.png" mode="aspectFit"></image>
			<view class="font_w success-txt">兑换成功!</view>
			
			<view class="trade-no-title font_28">订单编号</view>
		</view>
		
		<view class="out-trade-no">{{trade_no}}</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				trade_no: ''
			}
		},
		onLoad(option) {
			if(option.trade_no != undefined) {
				this.trade_no = option.trade_no;
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	
	.success-wrap {
		width: 200rpx;
		text-align: center;
		position: absolute;
		left: 50%;
		top: 20%;
		transform: translate(-50%, -50%);
	}
	
	.success-icon {
		display: inline-block;
		width: 70rpx;
		height: 70rpx;
	}
	
	.success-txt {
		color: #E32A2A;
		margin-bottom: 60rpx;
		font-size: 40rpx;
	}
	
	
	.out-trade-no {
		min-width: 360rpx;
		height: 70rpx;
		text-align: center;
		font-size: 50rpx;
		position: absolute;
		left: 50%;
		top: 32%;
		transform: translate(-50%, -50%);
		border-radius: 30rpx;
		background-color: #EAEAEA;
	}
	
	
</style>

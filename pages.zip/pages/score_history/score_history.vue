<template>
	<view>
		<!-- 积分记录 -->
		
		<view class="his-item" v-for="(item, index) in history" :key="index">
			<view class="score-info"> 
				<text class="score-type color_32">{{reason_arr[item.reason]}}</text>
				<text :class="{color_red :(item.type == 1)}" class="reduce-price color_96">
					<block v-if="item.type == 2">-</block>
					<block v-else>+</block>
					{{item.change_score}}
				</text>
				<image class="money-icon trade-money-icon" src="../../static/images/shop-score.png" mode="aspectFit"></image>
			</view>
			<view class="font_24 color_96">
				兑换时间:<text class="dh-time">{{item.addtime}}</text>
			</view>
			
		</view>
		
		
			
		
	</view>
</template>

<script>
	const app = getApp();
	
	export default {
		data() {
			return {
				course_info: {},
				history: {},
				reason_arr: {
					'1': '每日登录',
					'2': '阅读文章',
					'3': '留言',
					'4': '答题',
					'5': '商城兑换'
				}
			}
		},
		onLoad() {
			this.getScoreHistory();
		},
		methods: {
			
			getScoreHistory(){
				let that = this;
				uni.request({
					url: app.globalData.site_url+'/appapi/?s=User.GetScoreHistory',
					method: 'GET',
					data: {
						'uid': app.globalData.userInfo.id,
						'token': app.globalData.userInfo.token
					},
					success: res => {
						console.log(res);
						if(res.data.data.code == 0) {
							that.history = res.data.data.info[0];
						}
					},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
</script>

<style>
	
	page {
		background-color: #FAFAFA;
	}
	
	.his-item {
		width: 96%;
		height: 130rpx;
		margin: 0 auto 10rpx;
		padding-top: 10rpx;
		padding-left: 15rpx;
		background-color: #FFFFFF;	
		border-radius: 15rpx;
	}
	
	.trade-no {
		
	}
	
	.score-info {
		height: 60rpx;
		margin-bottom: 20rpx;
		display: flex;
		align-items: center;
		position: relative;
	}
	
	.score-type {
		max-width: 66%;
		text-overflow: ellipsis;
		overflow: hidden;
		white-space: nowrap;
	}
	
	.shouli {
		margin-left: 10rpx;
		display: inline-block;
		padding: 4rpx;
		border: 2rpx solid #E32A2A;
		border-radius: 5rpx;
		color: #E32A2A;
	}
	
	.trade-money-icon {
		position: absolute;
		right: 40rpx;
	}
	.reduce-price {
		width: 150rpx;
		text-align: right;
		position: absolute;
		right: 90rpx;
	}
	
	.dh-time {
		display: inline-block;
		padding-left: 10rpx;
	}
	
	
	
</style>
